# Portafolio - Esperanza Gonzalez

Portafolio personal para la prueba de Desarrollo de portafolio de un producto digital.

## Publicación con GitHub Pages
1. Sube estos archivos a un repositorio público.
2. En GitHub: Settings > Pages.
3. En Build and deployment selecciona Deploy from a branch.
4. Selecciona main y / (root), luego Save.
